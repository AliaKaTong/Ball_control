/* --COPYRIGHT--,BSD
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
/******************************************************************************
 * MSP432 Empty Project
 *
 * Description: An empty project that uses DriverLib
 *
 *                MSP432P401
 *             ------------------
 *         /|\|                  |
 *          | |                  |
 *          --|RST               |
 *            |                  |
 *            |                  |
 *            |                  |
 *            |                  |
 *            |                  |
 * Author: 
*******************************************************************************/
/* DriverLib Includes */
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>

/* Standard Includes */
#include <stdint.h>
#include <stdbool.h>

#include "sysinit.h"
#include "usart.h"
#include "delay.h"

#include "led.h"
#include "key.h"
#include "timA.h"
#include "oled.h"
#include "bmp.h"
#include "servo.h"

///* DMA Control Table */
//#if defined(__TI_COMPILER_VERSION__)
//#pragma DATA_ALIGN(controlTable, 1024)
//#elif defined(__IAR_SYSTEMS_ICC__)
//#pragma data_alignment=1024
//#elif defined(__GNUC__)
//__attribute__ ((aligned (1024)))
//#elif defined(__CC_ARM)
//__align(1024)
//#endif

uint8_t get_data_flag = 0;   //1����ʾ�յ�openMV����
uint8_t control_flag = 0;  //1������PID����

uint8_t str_buff[64];	
uint8_t controlTable[1024];
uint8_t recBuffer[2];
float val_1 = 0,val_2 = 0;  //1��2�Ŷ������Ŀ���ֵs
float val_1d = 0,val_2d = 0;  //1��2�Ŷ������Ŀ���ֵs
uint8_t ua2_rxdata = 0;
uint8_t ua2_flag = 0;  //1����ʾ����2���յ�����
uint8_t ua2_data;
uint8_t draw_flag = 0;  //1����ʾ��ʼ��
uint8_t t = 0; //��ʱ������
uint8_t draw_round1 = 0; //1:˳ʱ��Բ
uint8_t draw_round2 = 0; //1:��ʱ��Բ
uint8_t draw_line_45 = 0; //1:��ֱ��
uint8_t draw_line_90 = 0; //1:��ֱ��


#define _PI_2  1.57079632679
#define _PI    3.14159265359
#define _3PI_2 4.71238898038
#define _2PI   6.28318530718

#define _round(x) ((x) >= 0 ? (long)((x) + 0.5) : (long)((x) - 0.5))

const int sine_array[200] = {
    0, 79, 158, 237, 316, 395, 473, 552, 631, 710,
    789, 867, 946, 1024, 1103, 1181, 1260, 1338, 1416, 1494,
    1572, 1650, 1728, 1806, 1883, 1961, 2038, 2115, 2192, 2269,
    2346, 2423, 2499, 2575, 2652, 2728, 2804, 2879, 2955, 3030,
    3105, 3180, 3255, 3329, 3404, 3478, 3552, 3625, 3699, 3772,
    3845, 3918, 3990, 4063, 4135, 4206, 4278, 4349, 4420, 4491,
    4561, 4631, 4701, 4770, 4840, 4909, 4977, 5046, 5113, 5181,
    5249, 5316, 5382, 5449, 5515, 5580, 5646, 5711, 5775, 5839,
    5903, 5967, 6030, 6093, 6155, 6217, 6279, 6340, 6401, 6461,
    6521, 6581, 6640, 6699, 6758, 6815, 6873, 6930, 6987, 7043,
    7099, 7154, 7209, 7264, 7318, 7371, 7424, 7477, 7529, 7581,
    7632, 7683, 7733, 7783, 7832, 7881, 7930, 7977, 8025, 8072,
    8118, 8164, 8209, 8254, 8298, 8342, 8385, 8428, 8470, 8512,
    8553, 8594, 8634, 8673, 8712, 8751, 8789, 8826, 8863, 8899,
    8935, 8970, 9005, 9039, 9072, 9105, 9138, 9169, 9201, 9231,
    9261, 9291, 9320, 9348, 9376, 9403, 9429, 9455, 9481, 9506,
    9530, 9554, 9577, 9599, 9621, 9642, 9663, 9683, 9702, 9721,
    9739, 9757, 9774, 9790, 9806, 9821, 9836, 9850, 9863, 9876,
    9888, 9899, 9910, 9920, 9930, 9939, 9947, 9955, 9962, 9969,
    9975, 9980, 9985, 9989, 9992, 9995, 9997, 9999, 10000, 10000
};

float _sin ( float a ) {
    if ( a < _PI_2 ) {
        return 0.0001 * sine_array[_round ( 126.6873 * a )];
    } else if ( a < _PI ) {
        return 0.0001 * sine_array[398 - _round ( 126.6873 * a )];
    } else if ( a < _3PI_2 ) {
        return -0.0001 * sine_array[-398 + _round ( 126.6873 * a )];
    } else {
        return -0.0001 * sine_array[796 - _round ( 126.6873 * a )];
    }
}

float _cos ( float a ) {
    float a_sin = a + _PI_2;
    a_sin = a_sin > _2PI ? a_sin - _2PI : a_sin;
    return _sin ( a_sin );
}


void pre_for_next()  //Ϊ��һ�ν���openMV����׼��
{
	WDTCTL = WDTPW | WDTHOLD; // ͣ�ÿ��Ź�
	
	/* Setting Control Indexes */  //���ÿ���ָ��
	MAP_DMA_setChannelControl(UDMA_PRI_SELECT | DMA_CH1_EUSCIA0RX,
				 UDMA_SIZE_8 | UDMA_SRC_INC_NONE | UDMA_DST_INC_8 | UDMA_ARB_1);
				 
	MAP_DMA_setChannelTransfer(UDMA_PRI_SELECT | DMA_CH1_EUSCIA0RX,
					UDMA_MODE_BASIC,
					(void*)UART_getReceiveBufferAddressForDMA(EUSCI_A0_BASE), &recBuffer,2);
					 				
	MAP_Interrupt_enableInterrupt(INT_DMA_INT1);					
	MAP_DMA_enableChannel(1);
}

void pre_next()
{
	draw_flag = 0; 
	draw_round1 = 0;
	draw_round2 = 0;
	draw_line_45 = 0;
	draw_line_90 = 0;
}


int main(void)
{
	/* Stop Watchdog  */
	MAP_WDT_A_holdTimer();

	SysInit();
	uart_init(115200);
	delay_init();

	OLED_Init(); 
	KEY_Init(0);  //0��ʾ��ʹ���ж�
	LED_Init();
	TimA0_Int_Init(4000,48);  //�������ڿ���  5ms�ж�һ��
//	TimA3_Int_Init(1000,48);  //		
	TimA1_PWM_Init(19999,48);  //		50Hz
	TimA2_PWM_Init(19999,48);  //		50Hz
	PID_param_init_1();   //��ʼ��PID����
	PID_param_init_2();
//	MAP_GPIO_setAsOutputPin(GPIO_PORT_P1, GPIO_PIN0);   //led��
	
//	MAP_SysTick_enableModule();
//	MAP_SysTick_setPeriod(336000);  //48000/48M  1ms�ж�һ�� 48000*7  7ms�ж�һ��
//	//MAP_Interrupt_enableSleepOnIsrExit();
//	MAP_SysTick_enableInterrupt();
	
//	//�ж����ȼ�����
//  MAP_Interrupt_setPriority(INT_DMA_INT1, (1 << 5));
//	MAP_Interrupt_setPriority(FAULT_SYSTICK, (2 << 5));
////	MAP_Interrupt_setPriority(INT_TA0_0, (2 << 5));
	Interrupt_enableMaster();

	printf("hello\r\n");
	OLED_ShowString(30, 0, "---TEST---", 16);
	MAP_Timer_A_setCompareValue(TIMER_A1_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_2,mid);  //P7.6
	MAP_Timer_A_setCompareValue(TIMER_A2_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_1,mid);  //P5.6
	delay_ms(1000);

//	float test = (3 * 3.14)/4;
//	printf ( "_sin is %f\n", _sin ( test ) );
//	printf ( "_cos is %f\n", _cos ( test ) );
	while(1)
	{		
		if(get_data_flag == 1)   //��ʾopenMV����
		{
			OLED_Clear();   
			sprintf((char *)str_buff,"%d",recBuffer[0]);  // Y
			OLED_ShowString(10,2,str_buff,16);
			sprintf((char *)str_buff,"%d",recBuffer[1]);  // X
			OLED_ShowString(10,4,str_buff,16);	
			pre_for_next();		 //Ϊ��һ�ν���openMV����׼��
			get_data_flag = 0;
		}
		if(ua2_flag == 1)
		{
			t = 0;
//			printf("����Ϊ ��%d\r\n",ua2_rxdata-48);
			switch(ua2_rxdata)
			{	case '0': printf("���Ӳ���\r\n"); set_pid_target_1(161);	set_pid_target_2(202); draw_flag=1;break;	
				case '1':	printf("ȥ1��\r\n");set_pid_target_1(235);	set_pid_target_2(199); pre_next(); break;
				case '2':	printf("ȥ2��\r\n");set_pid_target_1(237);	set_pid_target_2(125); pre_next(); break;
				case '3':	printf("ȥ3��\r\n");set_pid_target_1(235);	set_pid_target_2(50);  pre_next(); break;
				case '4':	printf("ȥ4��\r\n");set_pid_target_1(162);	set_pid_target_2(204); pre_next(); break;
				case '5':	printf("ȥ5��\r\n");set_pid_target_1(163);	set_pid_target_2(125); pre_next(); break;
				case '6':	printf("ȥ6��\r\n");set_pid_target_1(162);	set_pid_target_2(47);  pre_next(); break;
				case '7':	printf("ȥ7��\r\n");set_pid_target_1(84);	set_pid_target_2(200); 	pre_next(); break;
				case '8':	printf("ȥ8��\r\n");set_pid_target_1(83);	set_pid_target_2(122);  pre_next(); break;
				case '9':	printf("ȥ9��\r\n");set_pid_target_1(83);	set_pid_target_2(45);  	pre_next(); break;
				case 'a':printf("˳ʱ��Բ\r\n");draw_round1 = 1;draw_flag = 0; draw_round2 = 0 ; draw_line_45 = 0; draw_line_90 = 0; break; 
				case 'b':printf("��ʱ��Բ\r\n");draw_round2 = 1;draw_flag = 0;	 draw_round1 = 0; draw_line_45 = 0; draw_line_90 = 0; break; 
				case 'c':printf("����\r\n");draw_line_45 = 1;draw_flag = 0; draw_round1 = 0; draw_round2 = 0 ; draw_line_90 = 0; break; 
				case 'd':printf("ֱ��\r\n");draw_line_90 = 1;draw_flag = 0; draw_round1 = 0; draw_round2 = 0 ; draw_line_45 = 0; break; 
				default: printf("- .-��\r\n");pre_next(); break;
			}
			ua2_flag = 0;
		}
	}
}

void DMA_INT1_IRQHandler(void)   //����DMA���������ж�
{
	get_data_flag = 1;
	control_flag = 1;
}

// Uart2�����ж�
void EUSCIA2_IRQHandler(void)
{
    uint32_t status = MAP_UART_getEnabledInterruptStatus(EUSCI_A2_BASE);
    if (status & EUSCI_A_UART_RECEIVE_INTERRUPT_FLAG) //�����ж�
    {
			MAP_UART_clearInterruptFlag(EUSCI_A2_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT_FLAG); // ����жϱ�־λ
			ua2_flag = 1;
			ua2_rxdata = MAP_UART_receiveData(EUSCI_A2_BASE); // ��ʱ����
    }
}


//void SysTick_Handler(void)
//{
//	static int flag = 0;
//	flag++;
//	if(flag >= 143)
//	{
//		MAP_GPIO_toggleOutputOnPin(GPIO_PORT_P1, GPIO_PIN0);
//		flag = 0;
//	}
////	pid_control();
////	control_flag = 1;
//}


//				char t;
//			//��ʾͼƬ
//        OLED_DrawBMP(0, 0, 128, 64, BMP1);
//        delay_ms(300);
//        OLED_Clear(); //����

//        //��ʾ����
//        OLED_ShowChinese(0, 0, 0, 16);   //��

//        //��ʾ�ַ���
//        OLED_ShowString(8, 2, (uint8_t *)"ZHONGJINGYUAN", 16);

//        //��ʾ�ַ�������
//			for (t = ' '; t < '~'; t++)
//			{
//				OLED_ShowChar(48, 6, t, 16);	//��ʾASCII�ַ�
//				OLED_ShowNum(103, 6, t, 3, 16); //��ʾASCII�ַ�����ֵ
//			}

