#include "servo.h"


void pid_control()   //PID����
{
	//float val_1 = 0,val_2 = 0;  //1��2�Ŷ������Ŀ���ֵ
	val_1 = PID_realize_1(recBuffer[0]); //����X
	val_2 = PID_realize_2(recBuffer[1]); //����Y
	if(val_1 > 0)   // Xƫ�� 1���½� 2���½�
	{
		val_1 = (val_1 > 600) ? 600 : val_1;      
		MAP_Timer_A_setCompareValue(TIMER_A1_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_2,1900 + val_1);
	}
	else						// XƫС
	{
		val_1 = -val_1;
		val_1 = (val_1 > 600) ? 600 : val_1;
		MAP_Timer_A_setCompareValue(TIMER_A1_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_2,1900 - val_1);
	}
	
	if(val_2 > 0)		// Yƫ�� 2������ 1���½�
	{
		val_2 = (val_2 > 600) ? 600 : val_2;
		MAP_Timer_A_setCompareValue(TIMER_A2_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_1,1900 - val_2);
	}
	else						// YƫС 
	{
		val_2 = -val_2;
		val_2 = (val_2 > 600) ? 600 : val_2;
		MAP_Timer_A_setCompareValue(TIMER_A2_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_1,1900 + val_2);
	}
}






void Duoj_test()			//�������1
{
	MAP_Timer_A_setCompareValue(TIMER_A1_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_2,high);
	MAP_Timer_A_setCompareValue(TIMER_A2_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_1,high);
	delay_ms(3000);
	
	MAP_Timer_A_setCompareValue(TIMER_A1_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_2,mid);
	MAP_Timer_A_setCompareValue(TIMER_A2_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_1,mid);
	delay_ms(3000);
	
	MAP_Timer_A_setCompareValue(TIMER_A1_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_2,low);
	MAP_Timer_A_setCompareValue(TIMER_A2_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_1,low);
	delay_ms(3000);
}


void Duoj_test2()			//�������2  �����������ת
{
	static uint8_t A2_flag = 0 ;
	for(int i = 1300;i<2500;i++)
	{
		MAP_Timer_A_setCompareValue(TIMER_A1_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_2,i);
		//delay_ms(2);
	}
	for(int i = 2500;i>1300;i--)
	{
		MAP_Timer_A_setCompareValue(TIMER_A1_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_2,i);
		//delay_ms(2);
	}
	if(A2_flag == 0)
		{	MAP_Timer_A_setCompareValue(TIMER_A2_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_1,low);	delay_ms(3000);}
	if(A2_flag == 1)
		{	MAP_Timer_A_setCompareValue(TIMER_A2_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_1,mid);	delay_ms(3000);}
	if(A2_flag == 2)
		{	MAP_Timer_A_setCompareValue(TIMER_A2_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_1,high);	delay_ms(3000);}
	A2_flag++;
	if(A2_flag == 3)  A2_flag = 0;
}

void Duoj_test3()			//�������2  8���Ƕ�
{
	MAP_Timer_A_setCompareValue(TIMER_A1_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_2,low);  //1
	MAP_Timer_A_setCompareValue(TIMER_A2_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_1,mid);
	delay_ms(2000);
	
	MAP_Timer_A_setCompareValue(TIMER_A1_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_2,low);  //2
	MAP_Timer_A_setCompareValue(TIMER_A2_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_1,low);
	delay_ms(2000);
	
	MAP_Timer_A_setCompareValue(TIMER_A1_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_2,mid);  //3
	MAP_Timer_A_setCompareValue(TIMER_A2_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_1,low);
	delay_ms(2000);
	
	MAP_Timer_A_setCompareValue(TIMER_A1_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_2,high);  //4
	MAP_Timer_A_setCompareValue(TIMER_A2_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_1,low);
	delay_ms(2000);
	
	MAP_Timer_A_setCompareValue(TIMER_A1_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_2,high);  //5
	MAP_Timer_A_setCompareValue(TIMER_A2_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_1,mid);
	delay_ms(2000);
	
	MAP_Timer_A_setCompareValue(TIMER_A1_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_2,high);  //6
	MAP_Timer_A_setCompareValue(TIMER_A2_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_1,high);
	delay_ms(2000);
	
	MAP_Timer_A_setCompareValue(TIMER_A1_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_2,mid);  //7
	MAP_Timer_A_setCompareValue(TIMER_A2_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_1,high);
	delay_ms(2000);
	
	MAP_Timer_A_setCompareValue(TIMER_A1_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_2,low);  //8
	MAP_Timer_A_setCompareValue(TIMER_A2_BASE,TIMER_A_CAPTURECOMPARE_REGISTER_1,high);
	delay_ms(2000);
}






