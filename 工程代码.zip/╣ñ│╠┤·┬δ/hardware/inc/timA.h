/****************************************************/
// MSP432P401R
// 定时器A
// Bilibili：m-RNA
// E-mail:m-RNA@qq.com
// 创建日期:2021/8/26
/****************************************************/

#ifndef __RNA_TIMA_H
#define __RNA_TIMA_H
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>
#include "bsp_pid.h"
#include "protocol.h"

extern uint8_t TIMA2_CAP_STA;
extern uint16_t TIMA2_CAP_VAL;
extern uint8_t recBuffer[2]; // 0为 Y  1为 X
extern float val_1 ;
extern float val_2 ;  //1，2号舵机算出的控制值
extern float val_1d ;
extern float val_2d ;  //1，2号舵机算出的控制值
extern uint8_t control_flag;  //1：进行PID控制
extern uint8_t draw_flag ;  //1：表示开始画
extern uint8_t t; //定时器计数
extern uint8_t draw_line_45; //1:画直线
extern uint8_t draw_line_90; //1:画直线
extern uint8_t draw_round1; //1:顺时针圆
extern uint8_t draw_round2; //1:逆时针圆

void TimA0_Int_Init(uint16_t ccr0, uint16_t psc);
void TimA1_PWM_Init(uint16_t ccr0, uint16_t psc);
void TimA2_Cap_Init(void);

extern float _sin ( float a );
extern float _cos ( float a );

#endif
