#ifndef __BSP_PID_H
#define	__BSP_PID_H
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>

//#include "stm32f4xx.h"
//#include "./usart/bsp_debug_usart.h"

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef struct
{
    float target_val;           //Ŀ��ֵ
    float actual_val;        		//ʵ��ֵ
    float err;             			//����ƫ��ֵ
    float err_last;          		//������һ��ƫ��ֵ
    float Kp,Ki,Kd;          		//������������֡�΢��ϵ��
    float integral;          		//�������ֵ
}_pid;

extern void PID_param_init_1(void);
extern void set_pid_target_1(float temp_val);
extern float get_pid_target_1(void);
extern void set_p_i_d_1(float p, float i, float d);
extern float PID_realize_1(float actual_val);
extern void time_period_fun_1(void);

extern void PID_param_init_2(void);
extern void set_pid_target_2(float temp_val);
extern float get_pid_target_2(void);
extern void set_p_i_d_2(float p, float i, float d);
extern float PID_realize_2(float actual_val);
extern void time_period_fun_2(void);

#endif
